# LLM Fine-tuning with Qwen2.5-3B-Instruct

## Project Overview

This project implements QLoRA (4-bit quantized LoRA) fine-tuning for the **Qwen/Qwen2.5-3B-Instruct** model using PEFT + TRL frameworks. The setup is optimized for consumer hardware like RTX 3050 4GB with efficient memory usage through 4-bit quantization, small batch sizes (batch_size=1), gradient accumulation, and sequence length limits (seq_len<=1024).

**Dataset**: databricks/databricks-dolly-15k - A high-quality instruction-following dataset
**Hardware Requirements**: RTX 3050 4GB or similar (4GB+ VRAM recommended)
**Memory Optimization**: 4-bit quantization, gradient checkpointing, small batch sizes

## Quickstart

1. **Verify GPU Setup**: `python .\src\verify_gpu.py`
2. **Quick Inference Test**: `python .\src\quick_infer.py`
3. **Start Training**: `python .\src\train_qlora.py`

Ensure your virtual environment is activated and all dependencies are installed before running these commands.